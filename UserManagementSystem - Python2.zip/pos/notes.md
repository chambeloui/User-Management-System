# Activate venv
```
.\Scripts\activate.bat
```