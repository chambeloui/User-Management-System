# We import the packages we need for Flask - Web interface
from flask import Flask, flash, render_template, request, redirect, url_for
import sqlite3

# Those packages are to geenrate the Flask secret key
import random
import string

# Initialize Flask (it's a Class)
app = Flask(__name__)

# Generate a random secret key for the application of length 50
# This is needed to setup Flask
app.secret_key = ''.join(random.choice(string.ascii_letters) for _ in range(50))


# Global Variables
DB_PATH = 'pos_database.db'
KEY = 42
FIELDS_TO_ENCRYPT = ['email', 'address']
PASSWORD = 'aust123'


class DatabaseManager:
    def __init__(self, db_path):
        self.db_path = db_path
        self.connection = None
        self.cursor = None

    def connect(self):
        self.connection = sqlite3.connect(self.db_path)
        self.cursor = self.connection.cursor()

    def disconnect(self):
        if self.connection:
            self.connection.close()

    def check_duplicate_phone(self, phone):
        try:
            self.cursor.execute('''
                SELECT * FROM users WHERE phone = ?
            ''', (phone,))
            is_phone_number_duplicate = self.cursor.fetchone()

            if is_phone_number_duplicate:
                return True
            else:
                return False

        except sqlite3.Error as e:
            print(e)
            return None

    def create_user_table(self):
        try:
            self.connect()

            # The SQL query used to create the users table in teh database
            # self.cursor.execute is in sqlite3
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    phone TEXT,
                    email TEXT,
                    address TEXT
                )
            ''')

            # Do it
            self.connection.commit()

            print('Table created successfully')
        except sqlite3.Error as e:
            print('Could not create table')
            print(e)

    @staticmethod
    def simple_xor_encrypt(data):
        encrypted_data = data.copy()
        for field in FIELDS_TO_ENCRYPT:
            if field in encrypted_data:
                encrypted_data[field] = [ord(char) ^ KEY for char in encrypted_data[field]]
        return encrypted_data

    def insert_user(self, encrypted_data):
        try:
            if not self.check_duplicate_phone(encrypted_data["phone"]):
                print('No duplicates!')

                self.cursor.execute('''
                    INSERT INTO users (name, phone, email, address) VALUES (?, ?, ?, ?)
                ''', (
                    encrypted_data["name"],
                    encrypted_data["phone"],
                    ''.join([chr(char) for char in encrypted_data["email"]]),
                    ''.join([chr(char) for char in encrypted_data["address"]])
                ))
                self.connection.commit()
                return True
            else:
                print('Duplicate found')
                return False

        except sqlite3.Error as e:
            print(e)
            return False

    # Search by phone number (called when password is provided)
    def get_user_by_phone(self, name):
        try:
            self.cursor.execute('''
                SELECT * FROM users WHERE phone = ?
            ''', (name,))

            # Find a single entry (usually first)
            retrieved_user_data = self.cursor.fetchone()

            if retrieved_user_data:
                decrypted_data = self.decrypt_user_data(retrieved_user_data, KEY, FIELDS_TO_ENCRYPT, self.cursor)
                return decrypted_data
        except sqlite3.Error as e:
            print(e)
            return None

    # Search by phone number (called when password is not provided)
    def get_user_by_phone_encrypted(self, name):
        try:
            self.cursor.execute('''
                SELECT * FROM users WHERE phone = ?
            ''', (name,))
            retrieved_user_data = self.cursor.fetchone()
            if retrieved_user_data:
                data_dict = {
                    'id': retrieved_user_data[0],
                    'name': retrieved_user_data[1],
                    'phone': retrieved_user_data[2],
                    'email': retrieved_user_data[3],
                    'address': retrieved_user_data[4]
                }
                return data_dict
        except sqlite3.Error as e:
            print(e)
        return None

    @staticmethod
    def decrypt_user_data(data, key, fields_to_decrypt, cursor):
        decrypted_data = {}
        for i in range(len(data)):
            column_name = cursor.description[i][0]

            # Sensitive data iterator
            # 3- Email
            # 4 - Address
            if i == 3 or i == 4:
                # Check if the value is a string before applying XOR
                if isinstance(data[i], str):
                    decrypted_data[column_name] = ''.join([chr(ord(char) ^ key) for char in data[i]])
                else:
                    decrypted_data[column_name] = chr(data[i] ^ key)

            # Add the unencrypted user data to the decrypted data
            else:
                decrypted_data[column_name] = data[i]
        return decrypted_data


db_manager = DatabaseManager('pos_database.db')
db_manager.create_user_table()


@app.route('/')
def index():
    # ./templates/template(template_name)
    return render_template('index.html')


# GET: When u navigate to a page for it to give u data
# POST: When you give data to the page
@app.route('/add_user', methods=['GET', 'POST'])
def add_user():
    # Initialize and connect to the database
    db_manager.connect()

    # If user is supplying data
    # (Add user is clicked)
    if request.method == 'POST':
        user_data = {
            "name": request.form['name'],
            "phone": request.form['phone'],
            "email": request.form['email'],
            "address": request.form['address']
        }

        encrypted_data = db_manager.simple_xor_encrypt(user_data)
        if not db_manager.insert_user(encrypted_data):
            db_manager.disconnect()
            return render_template('add_user.html', error='Duplicate phone number found!')

        # Disconnect from the database after the operation is completed
        db_manager.disconnect()

        return redirect(url_for('index'))

    # Disconnect from the database in case of a GET request
    db_manager.disconnect()

    return render_template('add_user.html')


@app.route('/search_user', methods=['GET', 'POST'])
def search_user():
    # Initialize and connect to the database
    db_manager.connect()

    if request.method == 'POST':
        phone_number_to_search = request.form['phone_number_to_search']
        password = request.form['password']

        # Employee
        if password != '':
            if password == PASSWORD:
                retrieved_user_data = db_manager.get_user_by_phone(phone_number_to_search)
            else:
                db_manager.disconnect()
                return render_template('search_user.html', error='Incorrect Password')
        else:
            retrieved_user_data = db_manager.get_user_by_phone_encrypted(phone_number_to_search)

        # Disconnect from the database after the operation is completed
        db_manager.disconnect()

        if retrieved_user_data:
            return render_template('search_user.html', user_data=retrieved_user_data)
        else:
            flash('User not found.', 'error')

    # Disconnect from the database in case of a GET request
    db_manager.disconnect()

    return render_template('search_user.html')


if __name__ == "__main__":
    app.run(debug=True)